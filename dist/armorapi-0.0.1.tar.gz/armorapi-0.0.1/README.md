Python module for interacting with the Armor API.
